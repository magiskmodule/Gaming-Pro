#!/system/bin/sh

SKIPMOUNT=1
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
sleep 3
       ui_print " ———————————————————————————————— "
sleep 0.5                              
       ui_print "    ╭━━━┳━━━┳━━━┳━━━┳━━━╮     "
sleep 0.5
       ui_print "    ┃╭━╮┃╭━╮┃╭━╮┃╭━╮┃╭━╮┃     "
sleep 0.5
       ui_print "    ┃┃╱╰┫╰━╯┃╰━╯┃┃╱┃┃┃╱┃┃     "
sleep 0.5
       ui_print "    ┃┃╭━┫╭━━┫╭╮╭┫┃╱┃┃╰━╯┃     "
sleep 0.5
       ui_print "    ┃╰┻━┃┃╱╱┃┃┃╰┫╰━╯┃╭━╮┃     "
sleep 0.5
       ui_print "    ╰━━━┻╯╱╱╰╯╰━┻━━━┻╯╱╰╯     "
sleep 0.5
       ui_print " ———————————————————————————————— "
sleep 1
ui_print ""
                  ui_print " Cek Device  "
sleep 1
  ui_print "-"
  ui_print ""
  ui_print "      Device Info        : $(getprop ro.product.board) "
sleep 1
  ui_print "     Selinux Info         : $(getprop ro.boot.selinux) "
sleep 1
  ui_print "     Kernel Info         : $(uname -r) "
sleep 1
  ui_print "     Build Date Info       : $(getprop ro.system.build.date) "
sleep 1
  ui_print "     Rom Info            : $(getprop ro.build.flavor) "
sleep 0.5
  ui_print "    Description Rom Info : $(getprop ro.build.description) "
sleep 0.5
  ui_print "    Fingerprint Info     : $(getprop ro.build.fingerprint) "
  ui_print "   "
  ui_print "  "
  ui_print "- "

sleep 1

ui_print " INSTALL MODULE "

sleep 1

ui_print "- Extracting module files GPROA"
mkdir -p $MODPATH/system/bin
unzip -o "$ZIPFILE" 'GPROA' -d $MODPATH/system/bin >&2
chmod +x $MODPATH/system/bin/GPROA

sleep 1

ui_print ""
unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'system.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2

if getprop ro.product.cpu.abi | grep -q "v8a"; then bit=i64; else bit=i32; fi
rm -rf /data/adb/modules/hwoverlay
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh
  ui_print "- Choose Your Render"
sleep 0.2
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➕ ] 𝙉𝙚𝙭𝙩"
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➖ ] 𝙄𝙣𝙨𝙩𝙖𝙡𝙡"
ui_print "   "
ui_print "   "
  ui_print "- hwui renderer type and Render Engine your device "
ui_print "- Select Your type renderer (sesuikan sama device - klo g support jangan maksa) "
ui_print ""
  ui_print " 1. OpenGL and RenderEngine"
  ui_print " 2. SkiaGL and RenderEngine"
  ui_print " 3. Vulkan and RenderEngine"
  ui_print " 4. SkiaVK and Render Engine"
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
tar -xf $MODPATH/Prop -C $MODPATH/
rm $MODPATH/Prop
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 4 ]; then
		AL=1
	fi
done
#

touch $MODPATH/system.prop

case $AL in
	1 )
		FCTEXTAD0="✅ OpenGL and RenderEngine Has Been Installed."
		echo "debug.hwui.renderer=openglthreaded" >> $MODPATH/system.prop
		echo "debug.renderengine.backend=openglthreaded" >> $MODPATH/system.prop
		;;
	2 )
		FCTEXTAD0="✅ SkiaGL and RenderEngine Has Been Installed."
		echo "debug.hwui.renderer=skiaglthreaded" > $MODPATH/system.prop
		echo "debug.renderengine.backend=skiaglthreaded" >> $MODPATH/system.prop
		;;
	3 )
		FCTEXTAD0="✅ Vulkan and RenderEngine Has Been Installed."
		echo "debug.hwui.renderer=vulkanthreaded" >> $MODPATH/system.prop
		echo "debug.renderengine.backend=vulkanthreaded" >> $MODPATH/system.prop
		;;
	4 )
		FCTEXTAD0="✅ SkiaVK and RenderEngine Has Been Installed."
		echo "debug.hwui.renderer=skiavkthreaded" >> $MODPATH/system.prop
		echo "debug.renderengine.backend=openglthreaded" >> $MODPATH/system.prop
		;;
	5 )
		FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝."
		;;
esac
sleep 1
ui_print "- $FCTEXTAD0"


sleep 2

      ui_print "-----------[succsess]--------------"

sleep 1

    ui_print "Joined to my channel for next update "
   ui_print "||||||||||||||||||||||||||||||||||||||"
 ui_print "Thanks for Credit and Support @RiProG" 
       ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "


