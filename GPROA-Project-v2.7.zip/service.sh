#!/system/bin/sh

#Credit : @ZxyonQiy |Arsene| My Channel @ZxyonQiyChnnel

sleep 5
nohup GPROA > /dev/null 2>&1 &