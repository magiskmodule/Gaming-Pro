SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

ui_print ""
ui_print "<>**********************<>"
ui_print "       Gaming Pro      "
ui_print "<>**********************<>"
ui_print " PERFORMANCE GAMING "
ui_print " Developer= Sizul767 x elki "
ui_print " Final Version "
ui_print " Version : Final 3.0 "
ui_print ""
ui_print "   THANKS FOR USING  "
ui_print ""
ui_print ""
ui_print " Your Device Can Do Better "