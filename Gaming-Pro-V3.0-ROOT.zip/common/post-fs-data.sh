#!/system/bin/sh
MODDIR=${0%/*}

#function(s)
BTFST() {
    for i in /sys/block/*/queue/read_ahead_kb
    do
    echo 2048 > $i
    done
    
    for i in /sys/block/*/queue/nr_requests
    do
    echo 512 > $i
    done
}

#main program
BTFST

MODDIR=${0%/*}

for i in /sys/block/*/queue/iostats
do
echo 0 > $i
done

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

if [ -a /system/etc/resolv.conf ]; then
	mkdir -p $MODDIR/system/etc/
	printf "nameserver 8.8.8.8\nnameserver 1.1.1.1" >> $MODDIR/system/etc/resolv.conf
	chmod 644 $MODDIR/system/etc/resolv.conf
fi