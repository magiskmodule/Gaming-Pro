#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
while true; do
# VM Management Tweaks Set Config
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '1' > /proc/sys/vm/panic_on_oom;
echo '5' > /proc/sys/vm/swappiness;
echo '15' > /proc/sys/vm/dirty_background_ratio;
echo '30' > /proc/sys/vm/dirty_ratio;
echo '500' > /proc/sys/vm/vfs_cache_pressure;
echo 0 >/sys/devices/soc/qpnp-flash-led-25/leds/led:torch_1/max_brightness;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo 1 >/sys/module/snd_soc_wcd9330/parameters/high_perf_mode;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
# TCP 
write /proc/sys/net/core/default_qdisc; fq_codel
write /proc/sys/net/ipv4/tcp_congestion_control; Deadline
fi
	for i in $STL $BML $MMC;
	do
		echo "sio" > $i/queue/scheduler; 
	done;
else
	for i in $STL $BML $MMC;
	do
		echo "cfq" > $i/queue/scheduler;
	done;
fi
#disable iostats to reduce overhead  # idea by kodos96 - thanks !
	if [ -e $i/queue/iostats ];
	then
		echo "0" > $i/queue/iostats;
	fi;
	
	if [ -e $i/queue/read_ahead_kb ];
	then
		echo "256" >  $i/queue/read_ahead_kb;
	fi;
done;
if [ -e /sys/devices/virtual/bdi/179:0/read_ahead_kb ];
then
    echo "2048" > /sys/devices/virtual/bdi/179:0/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:8/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:8/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:28/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:28/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:33/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:33/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/default/read_ahead_kb ];
  then
    echo "256" > /sys/devices/virtual/bdi/default/read_ahead_kb;
fi;
done;
echo "3" > /proc/sys/vm/page-cluster;
echo "3000" > /proc/sys/vm/dirty_expire_centisecs;
echo "500" > /proc/sys/vm/dirty_writeback_centisecs;
echo "9999" > /proc/sys/vm/min_free_kbytes;
echo "0" > /proc/sys/vm/oom_kill_allocating_task;
echo "0" > /proc/sys/vm/panic_on_oom;
echo "15" > /proc/sys/vm/dirty_background_ratio;
echo "30" > /proc/sys/vm/dirty_ratio;
echo "500" > /proc/sys/vm/vfs_cache_pressure;
echo "1" > /proc/sys/vm/overcommit_memory;
echo "4" > /proc/sys/vm/min_free_order_shift;
echo "0" > /proc/sys/vm/laptop_mode;
echo "0" > /proc/sys/vm/block_dump;
echo "1" > /proc/sys/vm/oom_dump_tasks;
echo "0" > /proc/sys/net/ipv4/tcp_timestamps;
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse;
echo "1" > /proc/sys/net/ipv4/tcp_sack;
echo "1" > /proc/sys/net/ipv4/tcp_dsack;
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle;
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling;
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout;
echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf;
echo "1" > /proc/sys/net/ipv4/route/flush;
echo "6144" > /proc/sys/net/ipv4/udp_rmem_min;
echo "6144" > /proc/sys/net/ipv4/udp_wmem_min;
echo "1" > /proc/sys/net/ipv4/tcp_rfc1337;
echo "0" > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo "0" > /proc/sys/net/ipv4/tcp_ecn;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_wmem;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_rmem;
echo "1" > /proc/sys/net/ipv4/tcp_fack;
echo "2" > /proc/sys/net/ipv4/tcp_synack_retries;
echo "2" > /proc/sys/net/ipv4/tcp_syn_retries;
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save;
echo "1800" > /proc/sys/net/ipv4/tcp_keepalive_time;
echo "0" > /proc/sys/net/ipv4/ip_forward;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/all/secure_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/secure_redirects;
echo "0" > /proc/sys/net/ipv4/ip_dynaddr;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "57344 57344 524288" > /proc/sys/net/ipv4/tcp_mem;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "2097152" > /proc/sys/net/core/rmem_max;
echo "2097152" > /proc/sys/net/core/wmem_max;
echo "262144" > /proc/sys/net/core/rmem_default;
echo "262144" > /proc/sys/net/core/wmem_default;
echo "20480" > /proc/sys/net/core/optmem_max;
echo "2500" > /proc/sys/net/core/netdev_max_backlog;
echo "50" > /proc/sys/net/unix/max_dgram_qlen;
echo "500 512000 64 2048" > /proc/sys/kernel/sem;
echo "268435456" > /proc/sys/kernel/shmmax;
echo "2097152" > /proc/sys/kernel/shmall;
echo "4096" > /proc/sys/kernel/shmmni;
echo "2048" > /proc/sys/kernel/msgmni;
echo "64000" > /proc/sys/kernel/msgmax;
echo "30" > /proc/sys/kernel/panic;
echo "0" > /proc/sys/kernel/panic_on_oops;
echo "5000" > /proc/sys/kernel/threads-max;
echo "10" > /proc/sys/fs/lease-break-time;
echo "65536" > /proc/sys/fs/file-max;
export up_threshold=100
# Scheduler Tweaks
if [ -f /sys/kernel/debug/sched_features; ]; 
then
echo 'TTWU_QUEUE' > /sys/kernel/debug/sched_features;
fi;
if [ -e /sys/kernel/debug/sched_features ]; then
 busybox echo "NEXT_BUDDY" > /sys/kernel/debug/sched_features
 busybox echo "NO_TTWU_QUEUE" > /sys/kernel/debug/sched_features
 busybox echo "UTIL_EST" > /sys/kernel/debug/sched_features
 busybox echo "ARCH_CAPACITY" > /sys/kernel/debug/sched_features
 busybox echo "ARCH_POWER" > /sys/kernel/debug/sched_features
 busybox echo "ENERGY_AWARE" > /sys/kernel/debug/sched_features
fi 2>/dev/null
# addr config
if [ -d /sys/kernel/debug ]; then
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/ab
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/ib
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/mas
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/slv
 echo "0" > /sys/kernel/debug/msm-bus-dbg/shell-client/update_request
fi 2>/dev/null
if [ -e "/sys/kernel/debug/sched_features" ]; then
busybox mount -t debugfs none /sys/kernel/debug;
busybox echo "NO_AFFINE_WAKEUPS" > /sys/kernel/debug/sched_features;
busybox echo "NO_ARCH_POWER" > /sys/kernel/debug/sched_features;
busybox echo "NO_CACHE_HOT_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_DOUBLE_TICK" > /sys/kernel/debug/sched_features;
busybox echo "NO_FORCE_SD_OVERLAP" > /sys/kernel/debug/sched_features;
busybox echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_HRTICK" > /sys/kernel/debug/sched_features;
busybox echo "NO_LAST_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_LB_BIAS" > /sys/kernel/debug/sched_features;
busybox echo "NO_LB_MIN" > /sys/kernel/debug/sched_features;
busybox echo "NO_NEW_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_NEXT_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_NONTASK_POWER" > /sys/kernel/debug/sched_features;
busybox echo "NO_NORMALIZED_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_OWNER_SPIN" > /sys/kernel/debug/sched_features;
busybox echo "NO_RT_RUNTIME_SHARE" > /sys/kernel/debug/sched_features;
busybox echo "NO_START_DEBIT" > /sys/kernel/debug/sched_features;
busybox umount /sys/kernel/debug;

for X in $(ls -d /proc/*); do
 lock_val "0" $X/oom_score_adj
 lock_val "0" $X/oom_adj
 lock_val "100" $X/sched_init_task_load
done

for i in $(pgrep -x init); do
 lock_val "-1000" /proc/$i/oom_score_adj
 lock_val "-17" /proc/$i/oom_adj
done
# cpu sched load enable
CORES=$(cat /proc/cpuinfo | grep "processor" | wc -l);
CORES1=$(expr $CORES - 1);
CORES2=$(seq 0 $CORES1);
for C in $CORES2; do
 lock_val "-6" /sys/devices/system/cpu/cpu$C/sched_load_boost
done
# Reserve 90% IO bandwith for foreground tasks
lock_val "1000" /dev/blkio/c.weight
lock_val "1000" /dev/blkio/blkio.leaf_weight
lock_val "100" /dev/blkio/background/blkio.weight
lock_val "100" /dev/blkio/background/blkio.leaf_weight
# disable gpu throttling
if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
 GPU=/sys/class/kgsl/kgsl-3d0;
else
 GPU=/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0;
fi
if [ -e $GPU/devfreq/adrenoboost ]; then
 lock_val "3" $GPU/devfreq/adrenoboost
 lock_val "0" $GPU/throttling
fi
if [ -e "/sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate" ]; then
 lock_val "Y" /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate
 lock_val "1" /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate
fi
# disable ksm and uksm
if [ -d /sys/kernel ]; then
 lock_val "0" /sys/kernel/sched/arch_power
 lock_val "0" /sys/kernel/mm/ksm/run
 lock_val "0" /sys/kernel/mm/uksm/run
fi

lock_val "0" /proc/sys/debug/exception-trace

lock_val "0" /proc/sys/fs/dir-notify-enable
lock_val "0" /proc/sys/kernel/hung_task_timeout_secs

if [ -d /sys/module ]; then
 lock_val "Y" /sys/module/bluetooth/parameters/disable_ertm
 lock_val "Y" /sys/module/bluetooth/parameters/disable_esco
 lock_val "0" /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
 lock_val "0" /sys/module/dwc3/parameters/ep_addr_txdbg_mask
 lock_val "0" /sys/module/dwc3_msm/parameters/disable_host_mode
 lock_val "0" /sys/module/hid_apple/parameters/fnmode
 lock_val "0" > /sys/module/hid/parameters/ignore_special_drivers
 lock_val "N" /sys/module/hid_magicmouse/parameters/emulate_3button
 lock_val "N" /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
 lock_val "0" /sys/module/hid_magicmouse/parameters/scroll_speed
 lock_val "Y" /sys/module/mdss_fb/parameters/backlight_dimmer
 lock_val "Y" /sys/module/workqueue/parameters/power_efficient
 lock_val "N" /sys/module/sync/parameters/fsync_enabled
 lock_val "0" /sys/module/binder/parameters/debug_mask
 lock_val "0" /sys/module/debug/parameters/enable_event_log
 lock_val "0" /sys/module/glink/parameters/debug_mask
 lock_val "N" /sys/module/ip6_tunnel/parameters/log_ecn_error
 lock_val "0" /sys/module/subsystem_restart/parameters/enable_ramdumps
 lock_val "0" /sys/module/lowmemorykiller/parameters/debug_level
 lock_val "0" /sys/module/msm_show_resume_irq/parameters/debug_mask
 lock_val "0" /sys/module/msm_smd_pkt/parameters/debug_mask
 lock_val "N" /sys/module/sit/parameters/log_ecn_error
 lock_val "0" /sys/module/smp2p/parameters/debug_mask
 lock_val "0" /sys/module/usb_bam/parameters/enable_event_log
 lock_val "Y" /sys/module/printk/parameters/console_suspend
 lock_val "N" /sys/module/printk/parameters/cpu
 lock_val "Y" /sys/module/printk/parameters/ignore_loglevel
 lock_val "N" /sys/module/printk/parameters/pid
 lock_val "N" /sys/module/printk/parameters/time
 lock_val "0" /sys/module/service_locator/parameters/enable
 lock_val "1" /sys/module/subsystem_restart/parameters/disable_restart_work
fi

for i in $(find /sys/class/net -type l); do
 lock_val "128" $i/tx_queue_len;
done;
# disable autosmp
if [ -e /sys/module/autosmp/parameters/enabled ]; then
 lock_val "N" /sys/module/autosmp/parameters/enabled
fi
# disable gpu log
if [ -d /sys/kernel/debug/kgsl/kgsl-3d0 ]; then
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/profiling/enable
fi
# reduce interval
pi="ls -d /sys/class/devfreq/*";
for i in $pi; do
 lock_val "0" $i/polling_interval
done
# disable async
if [ -e /sys/power/pm_async ]; then
 lock_val "0" /sys/power/pm_async
fi
# vm memory optimized
if [ -d /proc/sys/vm ]; then
 lock_val "1" /proc/sys/vm/overcommit_memory
 lock_val "100" /proc/sys/vm/overcommit_ratio
 lock_val "0" /proc/sys/vm/oom_kill_allocating_task
 lock_val "0" /proc/sys/vm/block_dump
 lock_val "1" /proc/sys/vm/oom_dump_tasks
 lock_val "1" /proc/sys/vm/stat_interval
 lock_val "0" /proc/sys/vm/panic_on_oom
 lock_val "30" /proc/sys/vm/watermark_scale_factor
 lock_val "0" /proc/sys/vm/page-cluster
fi
if [ -d /sys/block/mmcblk1/queue ]; then
 lock_val "1024" /sys/block/mmcblk1/queue/read_ahead_kb
fi
# set kernel tunning
if [ -e /proc/sys/kernel/sched_rt_period_us ]; then
 lock_val "1000000" /proc/sys/kernel/sched_rt_period_us
fi
if [ -e /dev/cpuctl/cpu.rt_period_us ]; then
 lock_val "1000000" /dev/cpuctl/cpu.rt_period_us
fi
# disable adreno idler
if [ -e /sys/module/adreno_idler/parameters/adreno_idler_active ]; then
 lock_val "N" /sys/module/adreno_idler/parameters/adreno_idler_active
fi
# increase sched domain
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "busy_factor"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "imbalance_pct"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "max_interval"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "min_interval"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "cache_nice_tries"); do
 lock_val "0" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "flags"); do
 lock_val "0" $m
done
# disable process reclaim
if [ -e /sys/module/process_reclaim/parameters/enable_process_reclaim ]; then
 lock_val "0" /sys/module/process_reclaim/parameters/enable_process_reclaim
fi
# zcache optimized
if [ -e /sys/module/zcache/parameters/max_pool_percent ]; then
 lock_val "100" /sys/module/zcache/parameters/max_pool_percent
fi
# disable ulps display
if [ -d /sys/kernel/debug/mdss_panel_fb0/intf0 ]; then
 lock_val "-1" /sys/kernel/debug/mdss_panel_fb0/intf0/max_refresh_rate
 lock_val "N" /sys/kernel/debug/mdss_panel_fb0/intf0/ulps_suspend_enabled
 lock_val "N" /sys/kernel/debug/mdss_panel_fb0/intf0/ulps_feature_enabled
fi
# disable state
cstate=$(ls -d /sys/devices/system/cpu/*/cpuidle/*)
for i in $cstate; do
 lock_val "1" $i/disable
done
#hotplug parameters
if [ -e /sys/module/pm_hotplug/parameters/loadl ]; then
echo 40 > /sys/module/pm_hotplug/parameters/loadl;
echo 90 > /sys/module/pm_hotplug/parameters/loadh;
echo 50 > /sys/module/pm_hotplug/parameters/loadl_scroff;
echo 100 > /sys/module/pm_hotplug/parameters/loadh_scroff;
echo 100 > /sys/module/pm_hotplug/parameters/rate;
echo 400 > /sys/module/pm_hotplug/parameters/rate_cpuon;
echo 400 > /sys/module/pm_hotplug/parameters/rate_scroff;
echo 500000 > /sys/module/pm_hotplug/parameters/freq_cpu1on;
#fi;
#smooth scaling parameters
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/smooth_target ]; then
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_target;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_offset;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_step;
fi;
#enable sched_mc
if [ -e /sys/devices/system/cpu/sched_mc_power_savings ]; then 
	echo 0 > /sys/devices/system/cpu/sched_mc_power_savings;
fi;
#enable AFTR
if [ -e /sys/module/cpuidle/parameters/enable_mask ]; then 
echo 3 > /sys/module/cpuidle/parameters/enable_mask;
fi;
#brightness settings
#if [ -e /sys/class/misc/brightness_curve/min_bl ]; then 
echo 20 > /sys/class/misc/brightness_curve/min_bl;
echo 1 > /sys/class/misc/brightness_curve/min_gamma;	
echo 24 > /sys/class/misc/brightness_curve/max_gamma;
fi;

echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/deepsleep_cpulevel;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/deepsleep_buslevel;
#gpu clock, threshold and voltage
echo "100%" > /sys/class/misc/gpu_clock_control/gpu_control;

echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/time
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo "0 0 0 0" > /proc/sys/kernel/printk
# CPU & Touch Boost
if [ -e "/sys/module/cpu_boost/parameters/boost_ms" ]; then
	echo "180" > /sys/module/cpu_boost/parameters/boost_ms
fi
if [ -e "/sys/module/msm_performance/parameters/touchboost" ]; then
	echo "1" > /sys/module/msm_performance/parameters/touchboost
fi
if [ -e /sys/power/pnpmgr/touch_boost ]; then
	echo "1" > /sys/power/pnpmgr/touch_boost
fi
if [ -e /sys/module/mmc_core/parameters/use_spi_crc ]; then
 echo '1' > /sys/module/mmc_core/parameters/use_spi_crc
fi
# TCP
if [ -e /sys/kernel/debug/sched_features ]; then
	echo NO_STRICT_SKIP_BUDDY > /sys/kernel/debug/sched_features
	echo NO_NONTASK_CAPACITY > /sys/kernel/debug/sched_features
fi
for queue in /sys/block/*/queue; do
   echo 0 > "${queue}"/add_random
   echo 0 > "${queue}"/iostats
   echo 2 > "${queue}"/nomerges
   echo 0 > "${queue}"/rotational
   echo 0 > "${queue}"/iosched/slice_idle
   echo 1 > "${queue}"/iosched/low_latency
   echo 1 > "${queue}"/iosched/group_idle
done 

chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor schedutil
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 100
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor msm-adreno-tz
write /sys/class/kgsl/kgsl-3d0/devfreq/governor msm-adreno-tz
write /sys/module/adreno_idler/parameters/adreno_idler_active 1
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /dev/cpuset/foreground/cpus 7-7
write /dev/cpuset/foreground/boost/cpus 7-7
write /dev/cpuset/top-app/cpus 0-7
done
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 100
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor performance
write /sys/class/kgsl/kgsl-3d0/devfreq/governor performance
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
# Boost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '180' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '180' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/pl
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
# TCP Type
sysctl -w net.ipv4.tcp_congestion_control=cubic
# Internet Tweaks
for tcp in /proc/sys/net/ipv4/
do
write "${tcp}ip_no_pmtu_disc" "0"
write "${tcp}tcp_ecn" "2"
write "${tcp}tcp_timestamps" "0"
write "${tcp}route.flush" "1"
write "${tcp}tcp_rfc1337" "1"
write "${tcp}tcp_tw_reuse" "1"
write "${tcp}tcp_sack" "1"
write "${tcp}tcp_fack" "1"
write "${tcp}tcp_fastopen" "3"
write "${tcp}tcp_tw_recycle" "1"
write "${tcp}tcp_no_metrics_save" "0"
write "${tcp}tcp_syncookies" "0"
write "${tcp}tcp_window_scaling" "1"
write "${tcp}tcp_keepalive_probes" "10"
write "${tcp}tcp_keepalive_intvl" "30"
write "${tcp}tcp_fin_timeout" "30"
write "${tcp}tcp_low_latency" "1"
write "${tcp}tcp_congestion_control" "cubic"
done
# Boost
if [ -e /proc/sys/kernel/hung_task_timeout_secs ]
then
echo 45 > /proc/sys/kernel/hung_task_timeout_secs;s
echo $SAMPLING_RATE > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/sampling_rate;
echo 192000 > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/sampling_rate;
echo 100 > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/up_threshold;
# Allow configuring of both cores
echo "1" > /sys/devices/system/cpu/cpu0/online;
echo "1" > /sys/devices/system/cpu/cpu1/online;
done
do echo $opt > /sys/kernel/debug/sched_features;
done
