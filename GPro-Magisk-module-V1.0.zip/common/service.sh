#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 10
chmod 777 /sys/class/power_supply/usb/*
chmod 777 /sys/class/power_supply/battery/*
chmod 777 /sys/class/power_supply/main/*
chmod 777 /sys/class/power_supply/bms/*
chmod 777 /sys/class/power_supply/pc_port/*
chmod 777 /sys/class/qcom-battery/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '100' > /sys/class/power_supply/bms/temp_cool
echo '380' > /sys/class/power_supply/bms/temp_hot
echo '380' > /sys/class/power_supply/bms/temp_warm
sleep 1
echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
#default value=35
echo "35" > /sys/devices/platform/kcal_ctrl.0/kcalmin 
echo "210 210 208" > /sys/devices/platform/kcal_ctrl.0/kcal 
#default value= 255=30
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_sat 
#default value=0
echo "0" > /sys/devices/platform/kcal_ctrl.0/kcal_hue 
#default value=255=127
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_val
#mod value=248=122 
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_cont
sleep 30
#enable=1 disable=0
echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
#default value=35
echo "35" > /sys/devices/platform/kcal_ctrl.0/kcalmin 
echo "210 210 208" > /sys/devices/platform/kcal_ctrl.0/kcal 
#default value= 255=30
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_sat 
#default value=0
echo "0" > /sys/devices/platform/kcal_ctrl.0/kcal_hue 
#default value=255=127
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_val
#mod value=248=122 
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_cont
sleep 30
#enable=1 disable=0
echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
#default value=35
echo "35" > /sys/devices/platform/kcal_ctrl.0/kcalmin 
echo "210 210 208" > /sys/devices/platform/kcal_ctrl.0/kcal 
#default value= 255=30
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_sat 
#default value=0
echo "0" > /sys/devices/platform/kcal_ctrl.0/kcal_hue 
#default value=255=127
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_val
#mod value=248=122 
echo "255" > /sys/devices/platform/kcal_ctrl.0/kcal_cont
# VM Management Tweaks Set Config
echo '0' > /proc/sys/vm/laptop_mode;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '1' > /proc/sys/vm/panic_on_oom;
echo '5' > /proc/sys/vm/swappiness;
echo '15' > /proc/sys/vm/dirty_background_ratio;
echo '30' > /proc/sys/vm/dirty_ratio;
echo '500' > /proc/sys/vm/vfs_cache_pressure;
# Disable Yellow Flash set Config;
echo 0 >/sys/devices/soc/qpnp-flash-led-25/leds/led:torch_1/max_brightness;
# Improve Touchscreen Set Config
echo '14005' > /sys/class/touch/switch/set_touchscreen;
# Misc Audio Optimizations Set Config
echo 1 >/sys/module/snd_soc_wcd9330/parameters/high_perf_mode;
#Force GPU 
echo '14005' > /sys/class/touch/switch/set_touchscreen;
# CPU Boost Tweaks 
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
# TCP 
write /proc/sys/net/core/default_qdisc; fq_codel
write /proc/sys/net/ipv4/tcp_congestion_control; Deadline
# Fast Charge
if [ -e /sys/kernel/fast_charge/force_fast_charge; ]; then
  echo "1" > /sys/kernel/fast_charge/force_fast_charge
fi
# Schedulers
echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 1000000 > /proc/sys/kernel/sched_migration_cost_ns
echo 0 > /proc/sys/kernel/sched_schedstats
echo 5000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 0 > /proc/sys/fs/dir-notify-enable
echo 1000000000 > $i/queue/iosched/back_seek_max
if [ -e /sys/kernel/debug/sched_features ]; then
	echo NEXT_BUDDY > /sys/kernel/debug/sched_features
	echo NO_STRICT_SKIP_BUDDY > /sys/kernel/debug/sched_features
	echo NO_NONTASK_CAPACITY > /sys/kernel/debug/sched_features
	echo TTWU_QUEUE > /sys/kernel/debug/sched_features 
 echo NO_NORMALIZED_SLEEPER > /sys/kernel/debug/sched_features
fi
# GMS blocker v1.1
### FeraDroid Engine v0.19 | By FeraVolt. 2016 ###
# Modified by AkumaHunt3r and Pedroginkgo (thx to his guys)
fi;
	for i in $STL $BML $MMC;
	do
		echo "sio" > $i/queue/scheduler; 
	done;
else
	for i in $STL $BML $MMC;
	do
		echo "cfq" > $i/queue/scheduler; 
		#cfq is generally better than noop
	done;
fi
# Optimize non-rotating storage; 
for i in $STL $BML $MMC;
do
	#IMPORTANT!
	if [ -e $i/queue/rotational ]; 
	then
		echo 0 > $i/queue/rotational; 
	fi;
	if [ -e $i/queue/nr_requests ];
	then
		echo 8192 > $i/queue/nr_requests; # for starters: keep it sane
	fi;
	# deadline/VR/SIO scheduler specific
	if [ -e $i/queue/iosched/fifo_batch ];
	then
		echo 1 > $i/queue/iosched/fifo_batch;
	fi;
	if [ -e $i/queue/iosched/writes_starved ];
	then
		echo 1 > $i/queue/iosched/writes_starved;
	fi;
#disable iostats to reduce overhead  # idea by kodos96 - thanks !
	if [ -e $i/queue/iostats ];
	then
		echo "0" > $i/queue/iostats;
	fi;
# Optimize for read- & write-throughput; 
# Optimize for readahead; 
	if [ -e $i/queue/read_ahead_kb ];
	then
		echo "256" >  $i/queue/read_ahead_kb;
	fi;
done;
if [ -e /sys/devices/virtual/bdi/179:0/read_ahead_kb ];
then
    echo "2048" > /sys/devices/virtual/bdi/179:0/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:8/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:8/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:28/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:28/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/179:33/read_ahead_kb ];
  then
    echo "2048" > /sys/devices/virtual/bdi/179:33/read_ahead_kb;
fi;
if [ -e /sys/devices/virtual/bdi/default/read_ahead_kb ];
  then
    echo "256" > /sys/devices/virtual/bdi/default/read_ahead_kb;
fi;
done;
echo 3 > /proc/sys/vm/page-cluster;
echo 3000 > /proc/sys/vm/dirty_expire_centisecs;
echo 500 > /proc/sys/vm/dirty_writeback_centisecs;
echo "9999" > /proc/sys/vm/min_free_kbytes;
echo "0" > /proc/sys/vm/oom_kill_allocating_task;
echo "0" > /proc/sys/vm/panic_on_oom;
echo "15" > /proc/sys/vm/dirty_background_ratio;
echo "30" > /proc/sys/vm/dirty_ratio;
echo "500" > /proc/sys/vm/vfs_cache_pressure;
echo "1" > /proc/sys/vm/overcommit_memory;
echo "4" > /proc/sys/vm/min_free_order_shift;
echo "0" > /proc/sys/vm/laptop_mode;
echo "0" > /proc/sys/vm/block_dump;
echo "1" > /proc/sys/vm/oom_dump_tasks;
echo "0" > /proc/sys/net/ipv4/tcp_timestamps;
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse;
echo "1" > /proc/sys/net/ipv4/tcp_sack;
echo "1" > /proc/sys/net/ipv4/tcp_dsack;
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle;
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling;
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout;
echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf;
echo "1" > /proc/sys/net/ipv4/route/flush;
echo "6144" > /proc/sys/net/ipv4/udp_rmem_min;
echo "6144" > /proc/sys/net/ipv4/udp_wmem_min;
echo "1" > /proc/sys/net/ipv4/tcp_rfc1337;
echo "0" > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo "0" > /proc/sys/net/ipv4/tcp_ecn;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_wmem;
echo "6144 87380 2097152" > /proc/sys/net/ipv4/tcp_rmem;
echo "1" > /proc/sys/net/ipv4/tcp_fack;
echo "2" > /proc/sys/net/ipv4/tcp_synack_retries;
echo "2" > /proc/sys/net/ipv4/tcp_syn_retries;
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save;
echo "1800" > /proc/sys/net/ipv4/tcp_keepalive_time;
echo "0" > /proc/sys/net/ipv4/ip_forward;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_source_route;
echo "0" > /proc/sys/net/ipv4/conf/all/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/accept_redirects;
echo "0" > /proc/sys/net/ipv4/conf/all/secure_redirects;
echo "0" > /proc/sys/net/ipv4/conf/default/secure_redirects;
echo "0" > /proc/sys/net/ipv4/ip_dynaddr;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "57344 57344 524288" > /proc/sys/net/ipv4/tcp_mem;
echo "1440000" > /proc/sys/net/ipv4/tcp_max_tw_buckets;
echo "2097152" > /proc/sys/net/core/rmem_max;
echo "2097152" > /proc/sys/net/core/wmem_max;
echo "262144" > /proc/sys/net/core/rmem_default;
echo "262144" > /proc/sys/net/core/wmem_default;
echo "20480" > /proc/sys/net/core/optmem_max;
echo "2500" > /proc/sys/net/core/netdev_max_backlog;
echo "50" > /proc/sys/net/unix/max_dgram_qlen;
echo "500 512000 64 2048" > /proc/sys/kernel/sem;
echo "268435456" > /proc/sys/kernel/shmmax;
echo "2097152" > /proc/sys/kernel/shmall;
echo "4096" > /proc/sys/kernel/shmmni;
echo "2048" > /proc/sys/kernel/msgmni;
echo "64000" > /proc/sys/kernel/msgmax;
echo "30" > /proc/sys/kernel/panic;
echo "0" > /proc/sys/kernel/panic_on_oops;
echo "5000" > /proc/sys/kernel/threads-max;
echo "10" > /proc/sys/fs/lease-break-time;
echo "65536" > /proc/sys/fs/file-max;
export up_threshold=100
# Scheduler Tweaks
if [ -f /sys/kernel/debug/sched_features; ]; 
then
echo 'NEXT_BUDDY' > /sys/kernel/debug/sched_features;
echo 'TTWU_QUEUE' > /sys/kernel/debug/sched_features;
echo 'HRTICK' > sys/kernel/debug/sched_features;
fi;
# Graphics Enhancement
setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop persist.sys.use_dithering 1
setprop com.qc.hardware=1
setprop debug.qc.hardware=true
setprop debug.qctwa.statusbar=1
setprop debug.qctwa.preservebuf=1
setprop persist.service.lgospd.enable=0
setprop persist.service.pcsync.enable=0
if [ "$FREQ_LIST_LEN" == "13" ]; then
 CURRENT_FREQ=9;
 CURRENT_FREQ1=8;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=13;
 CURRENT_FREQM=12;
 CURRENT_FREQG=11;
 CURRENT_FREQU=10;
 CURRENT_FREQB1=13;
 CURRENT_FREQB2=11;
elif [ "$FREQ_LIST_LEN" == "12" ]; then
 CURRENT_FREQ=8;
 CURRENT_FREQ1=7;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=12;
 CURRENT_FREQM=11;
 CURRENT_FREQG=10;
 CURRENT_FREQU=9;
 CURRENT_FREQB1=12;
 CURRENT_FREQB2=10;
elif [ "$FREQ_LIST_LEN" == "11" ]; then
 CURRENT_FREQ=7;
 CURRENT_FREQ1=6;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=11;
 CURRENT_FREQM=10;
 CURRENT_FREQG=9;
 CURRENT_FREQU=8;
 CURRENT_FREQB1=11;
 CURRENT_FREQB2=9;
elif [ "$FREQ_LIST_LEN" == "10" ]; then
 CURRENT_FREQ=6;
 CURRENT_FREQ1=5;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=10;
 CURRENT_FREQM=9;
 CURRENT_FREQG=8;
 CURRENT_FREQU=7;
 CURRENT_FREQB1=10;
 CURRENT_FREQB2=8;
elif [ "$FREQ_LIST_LEN" == "9" ]; then
 CURRENT_FREQ=5;
 CURRENT_FREQ1=4;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=9;
 CURRENT_FREQM=8;
 CURRENT_FREQG=7;
 CURRENT_FREQU=6;
 CURRENT_FREQB1=9;
 CURRENT_FREQB2=7;
elif [ "$FREQ_LIST_LEN" == "8" ]; then
 CURRENT_FREQ=5;
 CURRENT_FREQ1=4;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=8;
 CURRENT_FREQM=7;
 CURRENT_FREQG=6;
 CURRENT_FREQU=5;
 CURRENT_FREQB1=8;
 CURRENT_FREQB2=6;
elif [ "$FREQ_LIST_LEN" == "7" ]; then
 CURRENT_FREQ=3;
 CURRENT_FREQ1=2;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=7;
 CURRENT_FREQM=6;
 CURRENT_FREQG=5;
 CURRENT_FREQU=4;
 CURRENT_FREQB1=7;
 CURRENT_FREQB2=5;
elif [ "$FREQ_LIST_LEN" == "6" ]; then
 CURRENT_FREQ=2;
 CURRENT_FREQ1=1;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=6;
 CURRENT_FREQM=5;
 CURRENT_FREQG=4;
 CURRENT_FREQU=3;
 CURRENT_FREQB1=6;
 CURRENT_FREQB2=4;
elif [ "$FREQ_LIST_LEN" == "5" ]; then
 CURRENT_FREQ=2;
 CURRENT_FREQ1=1;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=5;
 CURRENT_FREQM=4;
 CURRENT_FREQG=3;
 CURRENT_FREQU=2;
 CURRENT_FREQB1=5;
 CURRENT_FREQB2=3;
elif [ "$FREQ_LIST_LEN" == "4" ]; then
 CURRENT_FREQ=2;
 CURRENT_FREQ1=1;
 CURRENT_FREQ2=1;
 CURRENT_FREQD=4;
 CURRENT_FREQM=3;
 CURRENT_FREQG=2;
 CURRENT_FREQU=1;
 CURRENT_FREQB1=4;
 CURRENT_FREQB2=2;
fi;
FREQ_TO_SET=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQ);
FREQ_TO_SET1=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQ1);
FREQ_TO_SET2=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQ2);
FREQ_TO_SETD=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQD);
FREQ_TO_SETM=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQM);
FREQ_TO_SETG=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQG);
FREQ_TO_SETU=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQU);
FREQ_TO_SETB1=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQB1);
FREQ_TO_SETB2=$(echo $FREQ_LIST | cut -d " " -f $CURRENT_FREQB2);
if [ "$NUMPWL" == "13" ]; then
 BMGD=12
 BMGM=12
 BMGG=11
 BMGU=11
 NMGD=12
 NMGM=11
 NMGG=10
 NMGU=9
 BFGR=8
 NFGR=0
 FGRD=12
elif [ "$NUMPWL" == "12" ]; then
 BMGD=11
 BMGM=11
 BMGG=10
 BMGU=10
 NMGD=11
 NMGM=10
 NMGG=9
 NMGU=8
 BFGR=7
 NFGR=0
 FGRD=11
elif [ "$NUMPWL" == "11" ]; then
 BMGD=10
 BMGM=10
 BMGG=9
 BMGU=9
 NMGD=10
 NMGM=9
 NMGG=8
 NMGU=7
 BFGR=6
 NFGR=0
 FGRD=10
elif [ "$NUMPWL" == "10" ]; then
 BMGD=9
 BMGM=9
 BMGG=8
 BMGU=8
 NMGD=9
 NMGM=8
 NMGG=7
 NMGU=6
 BFGR=5
 BFGR1=4
 NFGR=0
 FGRD=9
elif [ "$NUMPWL" == "9" ]; then
 BMGD=8
 BMGM=8
 BMGG=7
 BMGU=7
 NMGD=8
 NMGM=7
 NMGG=6
 NMGU=5
 BFGR=4
 BFGR1=3
 NFGR=0
 FGRD=8
elif [ "$NUMPWL" == "8" ]; then
 BMGD=7
 BMGM=7
 BMGG=6
 BMGU=6
 NMGD=7
 NMGM=6
 NMGG=5
 NMGU=4
 BFGR=3
 BFGR1=2
 NFGR=0
 FGRD=7
elif [ "$NUMPWL" == "7" ]; then
 BMGD=6
 BMGM=6
 BMGG=5
 BMGU=5
 NMGD=6
 NMGM=5
 NMGG=4
 NMGU=3
 BFGR=2
 BFGR1=1
 NFGR=0
 FGRD=6
elif [ "$NUMPWL" == "6" ]; then
 BMGD=5
 BMGM=5
 BMGG=4
 BMGU=4
 NMGD=5
 NMGM=4
 NMGG=3
 NMGU=2
 BFGR=1
 BFGR1=0
 NFGR=0
 FGRD=5
elif [ "$NUMPWL" == "5" ]; then
 BMGD=4
 BMGM=4
 BMGG=3
 BMGU=3
 NMGD=4
 NMGM=3
 NMGG=2
 NMGU=2
 BFGR=0
 BFGR1=0
 NFGR=0
 FGRD=4
elif [ "$NUMPWL" == "4" ]; then
 BMGD=3
 BMGM=3
 BMGG=2
 BMGU=2
 NMGD=3
 NMGM=2
 NMGG=2
 NMGU=2
 BFGR=0
 BFGR1=0
 NFGR=0
 FGRD=3
fi;
# first script
if [ "$DMB" == "0" ]; then
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SET2 > /sys/kernel/gpu/gpu_max_clock
 fi;
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SETD > /sys/kernel/gpu/gpu_min_clock
 fi;
elif [ "$DMB" == "1" ]; then
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SET2 > /sys/kernel/gpu/gpu_max_clock
 fi;
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SETM > /sys/kernel/gpu/gpu_min_clock
 fi;
elif [ "$DMB" == "2" ]; then
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SET2 > /sys/kernel/gpu/gpu_max_clock
 fi;
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SETG > /sys/kernel/gpu/gpu_min_clock
 fi;
elif [ "$DMB" == "3" ]; then
 if [ -e /sys/kernel/gpu/gpu_max_clock ]; then
 echo $FREQ_TO_SET2 > /sys/kernel/gpu/gpu_max_clock
 fi;
fi; 2>/dev/null
# second script
if [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/idle_timer ]; then
 echo "40" > /sys/class/kgsl/kgsl-3d0/idle_timer
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/idle_timer ]; then
 echo "40" > /sys/class/kgsl/kgsl-3d0/idle_timer
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/idle_timer ]; then
 echo "40" > /sys/class/kgsl/kgsl-3d0/idle_timer
 fi;
elif [ "$DMB" == "0" ] && [ "$FGR" == "0" ]; then
 if [ -e /sys/class/kgsl/kgsl-3d0/default_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/min_pwrlevel ]; then
 echo > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
 fi;
 if [ -e /sys/class/kgsl/kgsl-3d0/idle_timer ]; then
 echo "40" > /sys/class/kgsl/kgsl-3d0/idle_timer
 fi;
# Tweak the kernel task scheduler for improved overall system performance and user interface responsivness during all kind of possible workload based scenarios;
if [ -e /sys/kernel/debug/sched_features ]; then
 busybox echo "NO_HRTICK" > /sys/kernel/debug/sched_features
 busybox echo "NO_DOUBLE_TICK" > /sys/kernel/debug/sched_features
 busybox echo "NEXT_BUDDY" > /sys/kernel/debug/sched_features
 busybox echo "NO_TTWU_QUEUE" > /sys/kernel/debug/sched_features
 busybox echo "UTIL_EST" > /sys/kernel/debug/sched_features
 busybox echo "ARCH_CAPACITY" > /sys/kernel/debug/sched_features
 busybox echo "ARCH_POWER" > /sys/kernel/debug/sched_features
 busybox echo "ENERGY_AWARE" > /sys/kernel/debug/sched_features
fi 2>/dev/null
# addr config
if [ -d /sys/kernel/debug ]; then
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/ab
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/ib
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/mas
 echo "-1" > /sys/kernel/debug/msm-bus-dbg/shell-client/slv
 echo "0" > /sys/kernel/debug/msm-bus-dbg/shell-client/update_request
fi 2>/dev/null
if [ -e "/sys/kernel/debug/sched_features" ]; then
busybox mount -t debugfs none /sys/kernel/debug;
busybox echo "NO_AFFINE_WAKEUPS" > /sys/kernel/debug/sched_features;
busybox echo "NO_ARCH_POWER" > /sys/kernel/debug/sched_features;
busybox echo "NO_CACHE_HOT_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_DOUBLE_TICK" > /sys/kernel/debug/sched_features;
busybox echo "NO_FORCE_SD_OVERLAP" > /sys/kernel/debug/sched_features;
busybox echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_HRTICK" > /sys/kernel/debug/sched_features;
busybox echo "NO_LAST_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_LB_BIAS" > /sys/kernel/debug/sched_features;
busybox echo "NO_LB_MIN" > /sys/kernel/debug/sched_features;
busybox echo "NO_NEW_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_NEXT_BUDDY" > /sys/kernel/debug/sched_features;
busybox echo "NO_NONTASK_POWER" > /sys/kernel/debug/sched_features;
busybox echo "NO_NORMALIZED_SLEEPERS" > /sys/kernel/debug/sched_features;
busybox echo "NO_OWNER_SPIN" > /sys/kernel/debug/sched_features;
busybox echo "NO_RT_RUNTIME_SHARE" > /sys/kernel/debug/sched_features;
busybox echo "NO_START_DEBIT" > /sys/kernel/debug/sched_features;
busybox echo "NO_TTWU_QUEUE" > /sys/kernel/debug/sched_features;
busybox umount /sys/kernel/debug;
# cache allocation
if [ -e /sys/module/dm_bufio/parameters/max_cache_size_bytes ]; then
 MCSB=$(cat /sys/module/dm_bufio/parameters/max_cache_size_bytes);
 MCSB1=$((($MCSB*2)));
 MCSB2=$((($MCSB1*2)));
 echo $MCSB1 > /sys/module/dm_bufio/parameters/peak_allocated_bytes
 echo $MCSB2 > /sys/module/dm_bufio/parameters/max_cache_size_bytes
fi 2>/dev/null
if [ -e /sys/module/dm_bufio/parameters/retain_bytes ]; then
 RTBT=$(cat /sys/module/dm_bufio/parameters/retain_bytes);
 RTBT1=$(($RTBT*4));
 echo $RTBT1 > /sys/module/dm_bufio/parameters/retain_bytes
fi 2>/dev/null
# set default oom flag
for X in $(ls -d /proc/*); do
 lock_val "0" $X/oom_score_adj
 lock_val "0" $X/oom_adj
 lock_val "100" $X/sched_init_task_load
done
# fix magisk lag
for i in $(pgrep -x init); do
 lock_val "-1000" /proc/$i/oom_score_adj
 lock_val "-17" /proc/$i/oom_adj
done
# cpu sched load enable
CORES=$(cat /proc/cpuinfo | grep "processor" | wc -l);
CORES1=$(expr $CORES - 1);
CORES2=$(seq 0 $CORES1);
for C in $CORES2; do
 lock_val "-6" /sys/devices/system/cpu/cpu$C/sched_load_boost
done
# Reserve 90% IO bandwith for foreground tasks
lock_val "1000" /dev/blkio/blkio.weight
lock_val "1000" /dev/blkio/blkio.leaf_weight
lock_val "100" /dev/blkio/background/blkio.weight
lock_val "100" /dev/blkio/background/blkio.leaf_weight
# disable gpu throttling
if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
 GPU=/sys/class/kgsl/kgsl-3d0;
else
 GPU=/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0;
fi
if [ -e $GPU/devfreq/adrenoboost ]; then
 lock_val "3" $GPU/devfreq/adrenoboost
 lock_val "0" $GPU/throttling
fi
if [ -e "/sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate" ]; then
 lock_val "Y" /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate
 lock_val "1" /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate
fi
# disable ksm and uksm
if [ -d /sys/kernel ]; then
 lock_val "0" /sys/kernel/sched/arch_power
 lock_val "0" /sys/kernel/mm/ksm/run
 lock_val "0" /sys/kernel/mm/uksm/run
fi
# Disable exception-trace and reduce some overhead that is caused by a certain amount and percent of kernel logging, in case your kernel of choice have it enabled;
lock_val "0" /proc/sys/debug/exception-trace
# FileSystem (FS) optimized tweaks & enhancements for a improved userspace experience;
lock_val "0" /proc/sys/fs/dir-notify-enable
lock_val "0" /proc/sys/kernel/hung_task_timeout_secs
# Fully disable kernel printk console log spamming directly for less amount of useless wakeups (reduces overhead);
lock_val "0 0 0 0" /proc/sys/kernel/printk
# Turn off a few additional kernel debuggers and what not for gaining a slight boost in both performance and battery life;
if [ -d /sys/module ]; then
 lock_val "Y" /sys/module/bluetooth/parameters/disable_ertm
 lock_val "Y" /sys/module/bluetooth/parameters/disable_esco
 lock_val "0" /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
 lock_val "0" /sys/module/dwc3/parameters/ep_addr_txdbg_mask
 lock_val "0" /sys/module/dwc3_msm/parameters/disable_host_mode
 lock_val "0" /sys/module/hid_apple/parameters/fnmode
 lock_val "0" > /sys/module/hid/parameters/ignore_special_drivers
 lock_val "N" /sys/module/hid_magicmouse/parameters/emulate_3button
 lock_val "N" /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
 lock_val "0" /sys/module/hid_magicmouse/parameters/scroll_speed
 lock_val "Y" /sys/module/mdss_fb/parameters/backlight_dimmer
 lock_val "Y" /sys/module/workqueue/parameters/power_efficient
 lock_val "N" /sys/module/sync/parameters/fsync_enabled
 lock_val "0" /sys/module/binder/parameters/debug_mask
 lock_val "0" /sys/module/debug/parameters/enable_event_log
 lock_val "0" /sys/module/glink/parameters/debug_mask
 lock_val "N" /sys/module/ip6_tunnel/parameters/log_ecn_error
 lock_val "0" /sys/module/subsystem_restart/parameters/enable_ramdumps
 lock_val "0" /sys/module/lowmemorykiller/parameters/debug_level
 lock_val "0" /sys/module/msm_show_resume_irq/parameters/debug_mask
 lock_val "0" /sys/module/msm_smd_pkt/parameters/debug_mask
 lock_val "N" /sys/module/sit/parameters/log_ecn_error
 lock_val "0" /sys/module/smp2p/parameters/debug_mask
 lock_val "0" /sys/module/usb_bam/parameters/enable_event_log
 lock_val "Y" /sys/module/printk/parameters/console_suspend
 lock_val "N" /sys/module/printk/parameters/cpu
 lock_val "Y" /sys/module/printk/parameters/ignore_loglevel
 lock_val "N" /sys/module/printk/parameters/pid
 lock_val "N" /sys/module/printk/parameters/time
 lock_val "0" /sys/module/service_locator/parameters/enable
 lock_val "1" /sys/module/subsystem_restart/parameters/disable_restart_work
fi
# tweak and decrease tx_queue_len default stock value(s) for less amount of generated bufferbloat and for gaining slightly faster network speed and performance;
for i in $(find /sys/class/net -type l); do
 lock_val "128" $i/tx_queue_len;
done;
# disable autosmp
if [ -e /sys/module/autosmp/parameters/enabled ]; then
 lock_val "N" /sys/module/autosmp/parameters/enabled
fi
# disable gpu log
if [ -d /sys/kernel/debug/kgsl/kgsl-3d0 ]; then
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
 lock_val "0" /sys/kernel/debug/kgsl/kgsl-3d0/profiling/enable
fi
# reduce interval
pi="ls -d /sys/class/devfreq/*";
for i in $pi; do
 lock_val "0" $i/polling_interval
done
# disable async
if [ -e /sys/power/pm_async ]; then
 lock_val "0" /sys/power/pm_async
fi
# vm memory optimized
if [ -d /proc/sys/vm ]; then
 lock_val "1" /proc/sys/vm/overcommit_memory
 lock_val "100" /proc/sys/vm/overcommit_ratio
 lock_val "0" /proc/sys/vm/oom_kill_allocating_task
 lock_val "0" /proc/sys/vm/block_dump
 lock_val "1" /proc/sys/vm/oom_dump_tasks
 lock_val "1" /proc/sys/vm/stat_interval
 lock_val "0" /proc/sys/vm/panic_on_oom
 lock_val "30" /proc/sys/vm/watermark_scale_factor
 lock_val "0" /proc/sys/vm/page-cluster
fi
if [ -d /sys/block/mmcblk1/queue ]; then
 lock_val "1024" /sys/block/mmcblk1/queue/read_ahead_kb
fi
# optimized gpu
if [ -e /sys/class/kgsl/kgsl/full_cache_threshold ]; then
 lock_val "1000000000" /sys/class/kgsl/kgsl/full_cache_threshold
fi
if [ -e /sys/devices/virtual/kgsl/kgsl/full_cache_threshold ]; then
 lock_val "1000000000" /sys/devices/virtual/kgsl/kgsl/full_cache_threshold
fi
if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
 KGSL="/sys/class/kgsl/kgsl-3d0"
else
 KGSL="/sys/devices/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0"
fi
if [ -d $KGSL ]; then
 lock_val "1" $KGSL/force_no_nap
 lock_val "1" $KGSL/bus_split
 lock_val "1" $KGSL/force_bus_on
 lock_val "1" $KGSL/force_clk_on
 lock_val "1" $KGSL/force_rail_on
fi
# Kernel based tweaks that reduces the amount of wasted CPU cycles to maximum and gives back a huge amount of needed performance to both the system and the user;
if [ -d /proc/sys/kernel ]; then
 lock_val "0" /proc/sys/kernel/compat-log
 lock_val "1" /proc/sys/kernel/panic
 lock_val "1" /proc/sys/kernel/panic_on_oops
 lock_val "0" /proc/sys/kernel/softlockup_panic
 lock_val "100" /proc/sys/kernel/perf_cpu_time_max_percent
 lock_val "0" /proc/sys/kernel/nmi_watchdog
 lock_val "5" /proc/sys/kernel/sched_walt_init_task_load_pct
 lock_val "0" /proc/sys/kernel/sched_tunable_scaling
 lock_val "0" /proc/sys/kernel/sched_child_runs_first
 lock_val "1000000000" /proc/sys/kernel/max_lock_depth
 lock_val "0" /proc/sys/kernel/sched_sync_hint_enable
 lock_val "0" /proc/sys/kernel/sched_initial_task_util
 lock_val "1" /proc/sys/kernel/sched_cstate_aware
 lock_val "0" /proc/sys/kernel/sched_migration_cost_ns
 lock_val "0" /proc/sys/kernel/sched_shares_window_ns
 lock_val "1" /proc/sys/kernel/sched_time_avg_ms
 lock_val "1" /proc/sys/kernel/sched_nr_migrate
 lock_val "100000" /proc/sys/kernel/sched_min_granularity_ns
 lock_val "1000000" /proc/sys/kernel/sched_latency_ns
 lock_val "1000000000" /proc/sys/kernel/sched_wakeup_granularity_ns
fi
# set kernel tunning
if [ -e /proc/sys/kernel/sched_rt_period_us ]; then
 lock_val "1000000" /proc/sys/kernel/sched_rt_period_us
fi
if [ -e /dev/cpuctl/cpu.rt_period_us ]; then
 lock_val "1000000" /dev/cpuctl/cpu.rt_period_us
fi
# disable adreno idler
if [ -e /sys/module/adreno_idler/parameters/adreno_idler_active ]; then
 lock_val "N" /sys/module/adreno_idler/parameters/adreno_idler_active
fi
# lmk and vm memory optimized
MFK=$(($(cat /proc/sys/vm/min_free_kbytes)*2));
EFK=$(($(cat /proc/sys/vm/extra_free_kbytes)*2));
if [ -d /sys/module/lowmemorykiller/parameters ]; then
 lock_val "1" /sys/module/lowmemorykiller/parameters/enable_lmk
 lock_val "0" /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
 lock_val "1" /sys/module/lowmemorykiller/parameters/lmk_fast_run
 lock_val "8192" /sys/module/lowmemorykiller/parameters/cost
 lock_val "1" /sys/module/lowmemorykiller/parameters/oom_reaper
 lock_val "0" /sys/module/lowmemorykiller/parameters/debug_level
fi
if [ -d /proc/sys/vm ]; then
 lock_val "1" /proc/sys/vm/overcommit_memory
 lock_val "100" /proc/sys/vm/overcommit_ratio
 lock_val "0" /proc/sys/vm/oom_kill_allocating_task
 lock_val "0" /proc/sys/vm/block_dump
 lock_val "0" /proc/sys/vm/oom_dump_tasks
 lock_val "0" /proc/sys/vm/oom_kill_allocating_task
 lock_val "1" /proc/sys/vm/stat_interval
fi
# disable log and debug
for i in $(find /sys/ -name debug_mask); do
 lock_val "0" $i
done
for i in $(find /sys/ -name debug_level); do
 lock_val "0" $i
done
for i in $(find /sys/ -name edac_mc_log_ce); do
 lock_val "0" $i
done
for i in $(find /sys/ -name edac_mc_log_ue); do
 lock_val "0" $i
done
for i in $(find /sys/ -name enable_event_log); do
 lock_val "0" $i
done
for i in $(find /sys/ -name log_ecn_error); do
 lock_val "0" $i
done
for i in $(find /sys/ -name snapshot_crashdumper); do
 lock_val "0" $i
done
# increase sched domain
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "busy_factor"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "imbalance_pct"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "max_interval"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "min_interval"); do
 lock_val "1" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "cache_nice_tries"); do
 lock_val "0" $m
done
for m in $(find /proc/sys/kernel/sched_domain -type f -iname "flags"); do
 lock_val "0" $m
done
# disable fsync
if [ -e /sys/kernel/dyn_fsync/Dyn_fsync_active ]; then
 lock_val "0" /sys/kernel/dyn_fsync/Dyn_fsync_active
fi
if [ -e /sys/class/misc/fsynccontrol/fsync_enabled ]; then
 lock_val "0" /sys/class/misc/fsynccontrol/fsync_enabled
fi
if [ -e /sys/module/sync/parameters/fsync ]; then
 lock_val "0" /sys/module/sync/parameters/fsync
fi
if [ -e /sys/module/sync/parameters/fsync_enabled ]; then
 lock_val "N" /sys/module/sync/parameters/fsync_enabled
fi
for i in $(find /sys/devices/virtual -type f -iname "numa"); do
 lock_val "1" $i
done
if [ -e /sys/module/sync/parameters/auto_fsync_delay_sec ]; then
 lock_val "0" /sys/module/sync/parameters/auto_fsync_delay_sec
fi
# disable process reclaim
if [ -e /sys/module/process_reclaim/parameters/enable_process_reclaim ]; then
 lock_val "0" /sys/module/process_reclaim/parameters/enable_process_reclaim
fi
# zcache optimized
if [ -e /sys/module/zcache/parameters/max_pool_percent ]; then
 lock_val "100" /sys/module/zcache/parameters/max_pool_percent
fi
# disable ulps display
if [ -d /sys/kernel/debug/mdss_panel_fb0/intf0 ]; then
 lock_val "-1" /sys/kernel/debug/mdss_panel_fb0/intf0/max_refresh_rate
 lock_val "N" /sys/kernel/debug/mdss_panel_fb0/intf0/ulps_suspend_enabled
 lock_val "N" /sys/kernel/debug/mdss_panel_fb0/intf0/ulps_feature_enabled
fi
# disable state
cstate=$(ls -d /sys/devices/system/cpu/*/cpuidle/*)
for i in $cstate; do
 lock_val "1" $i/disable
done
#hotplug parameters
if [ -e /sys/module/pm_hotplug/parameters/loadl ]; then
echo 40 > /sys/module/pm_hotplug/parameters/loadl;
echo 90 > /sys/module/pm_hotplug/parameters/loadh;
echo 50 > /sys/module/pm_hotplug/parameters/loadl_scroff;
echo 100 > /sys/module/pm_hotplug/parameters/loadh_scroff;
echo 100 > /sys/module/pm_hotplug/parameters/rate;
echo 400 > /sys/module/pm_hotplug/parameters/rate_cpuon;
echo 400 > /sys/module/pm_hotplug/parameters/rate_scroff;
echo 500000 > /sys/module/pm_hotplug/parameters/freq_cpu1on;
#fi;
#smooth scaling parameters
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/smooth_target ]; then
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_target;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_offset;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/smooth_step;
fi;
#enable sched_mc
if [ -e /sys/devices/system/cpu/sched_mc_power_savings ]; then 
	echo 0 > /sys/devices/system/cpu/sched_mc_power_savings;
fi;
#enable AFTR
if [ -e /sys/module/cpuidle/parameters/enable_mask ]; then 
echo 3 > /sys/module/cpuidle/parameters/enable_mask;
fi;
#brightness settings
#if [ -e /sys/class/misc/brightness_curve/min_bl ]; then 
echo 20 > /sys/class/misc/brightness_curve/min_bl;
echo 1 > /sys/class/misc/brightness_curve/min_gamma;	
echo 24 > /sys/class/misc/brightness_curve/max_gamma;
fi;
#Disabled! Each phone has its own stable settings on these. Enable it on your own accord!
#deepsleep levels
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/deepsleep_cpulevel;
echo 0 > /sys/devices/system/cpu/cpu0/cpufreq/deepsleep_buslevel;
#gpu clock, threshold and voltage
echo "100%" > /sys/class/misc/gpu_clock_control/gpu_control;
#static bus frequency
echo "0 0 0 0 1 2 2 2" > /sys/devices/system/cpu/cpu0/cpufreq/busfreq_static;
echo disabled > /sys/devices/system/cpu/cpu0/cpufreq/busfreq_static;
# destinations
FILE=audio_policy_configuration.xml
MAP=`find $MODDIR/system -type f -name $FILE`
# patch audio policy
if echo $MAP | grep xml; then
  sed -i '/AUDIO_OUTPUT_FLAG_DEEP_BUFFER/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\samplingRates="192000"\
                             channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>' $MAP
  sed -i '/AUDIO_OUTPUT_FLAG_COMPRESS_OFFLOAD/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\samplingRates="192000"\
                             channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>' $MAP
  sed -i '/AUDIO_OUTPUT_FLAG_PRIMARY/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_24_BIT_PACKED"\samplingRates="192000"\                             channelMasks="AUDIO_CHANNEL_OUT_STEREO"/>' $MAP
  sed -i '/<mixPort name="primary input"/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_8_24_BIT"\samplingRates="192000"\                            channelMasks="AUDIO_CHANNEL_IN_MONO,AUDIO_CHANNEL_IN_STEREO,AUDIO_CHANNEL_IN_FRONT_BACK,AUDIO_CHANNEL_INDEX_MASK_3"/>' $MAP
  sed -i '/AUDIO_INPUT_FLAG_FAST/a\
                    <profile name="" format="AUDIO_FORMAT_PCM_8_24_BIT"\samplingRates="192000"\                             channelMasks="AUDIO_CHANNEL_IN_MONO,AUDIO_CHANNEL_IN_STEREO,AUDIO_CHANNEL_IN_FRONT_BACK,AUDIO_CHANNEL_INDEX_MASK_3"/>' $MAP
fi
# Reducing Some System load
echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/time
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work
echo "0" > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo "0 0 0 0" > /proc/sys/kernel/printk
# CPU & Touch Boost
if [ -e "/sys/module/cpu_boost/parameters/boost_ms" ]; then
	echo "180" > /sys/module/cpu_boost/parameters/boost_ms
fi
if [ -e "/sys/module/msm_performance/parameters/touchboost" ]; then
	echo "1" > /sys/module/msm_performance/parameters/touchboost
fi
if [ -e /sys/power/pnpmgr/touch_boost ]; then
	echo "1" > /sys/power/pnpmgr/touch_boost
fi
if [ -e /sys/module/mmc_core/parameters/use_spi_crc ]; then
 echo '1' > /sys/module/mmc_core/parameters/use_spi_crc
fi
# Sched Tweaks
echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns
echo 1000000 > /proc/sys/kernel/sched_migration_cost_ns
echo 0 > /proc/sys/kernel/sched_schedstats
echo 5000000 > /proc/sys/kernel/sched_wakeup_granularity_ns
echo 0 > /proc/sys/fs/dir-notify-enable
# TCP
echo 1 > /proc/sys/net/ipv4/tcp_ecn
echo 3 > /proc/sys/net/ipv4/tcp_fastopen
echo 0 > /proc/sys/net/ipv4/tcp_syncookies
if [ -e /sys/kernel/debug/sched_features ]; then
	echo NEXT_BUDDY > /sys/kernel/debug/sched_features
	echo NO_STRICT_SKIP_BUDDY > /sys/kernel/debug/sched_features
	echo NO_NONTASK_CAPACITY > /sys/kernel/debug/sched_features
	echo TTWU_QUEUE > /sys/kernel/debug/sched_features 
fi
for queue in /sys/block/*/queue; do
   echo 0 > "${queue}"/add_random
   echo 0 > "${queue}"/iostats
   echo 2 > "${queue}"/nomerges
   echo 0 > "${queue}"/rotational
   echo 0 > "${queue}"/iosched/slice_idle
   echo 1 > "${queue}"/iosched/low_latency
   echo 1 > "${queue}"/iosched/group_idle
done 
# Entropy
echo 512 > /proc/sys/kernel/random/read_wakeup_threshold
echo 1024 > /proc/sys/kernel/random/write_wakeup_threshold
# Oneplus FPS and tweaks
settings put global oneplus_screen_refresh_rate 0
setprop fw.max_users=5;
setprop fw.show_multiuserui=1;
setprop ro.config.hw_bt_pan_enable=true;
setprop ro.config.hide_bt_tethering=false;
setprop ro.config.hide_mirror_share=false;
setprop ro.config.hw_multiscreen=true;
setprop ro.config.hw_hideNetworkSpeed=false;
setprop ro.config.hw_simplecover=true;
setprop ro.camera.sound.forced=0;
setprop ro.config.hide_network_mode=false;
setprop dalvik.vm.checkjini false;
setprop ro.kernel.android.checkjni 0;
setprop ro.kernel.checkjni 0;
setprop ro.config.nocheckin 1;
setprop debug.systemui.latency_tracking 0;
setprop persist.sample.eyetracking.log 0;
setprop ro.com.google.locationfeatures 0;
setprop ro.com.google.networklocation 0;
setprop media.metrics.enabled 0;
setprop sys.debug.watchdog 0;
setprop logd.statistics 0;
setprop media.metrics 0;
setprop config.stats 0;
setprop persist.sys.loglevel 0;
setprop sys.log.app 0;
setprop persist.traced.enable 0;
setprop logd.statistics 0;
setprop persist.sample.eyetracking.log 0;
setprop debug.atrace.tags.enableflags 0;
setprop debugtool.anrhistory 0;
setprop ro.debuggable 1;
setprop profiler.debugmonitor false;
setprop profiler.launch false;
setprop profiler.hung.dumpdobugreport false;
setprop trustkernel.log.state disable;
setprop debug.mdpcomp.logs 0;
setprop debug.atrace.tags.enableflags 0;
setprop ro.logd.size.stats 0;
setprop debug.atrace.tags.enableflags 0;
fi;
# External SD Card Speed up
echo 'cfq' > /sys/block/mmcblk0/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/rotational
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '0' > /sys/block/mmcblk0/queue/add_random
echo '2' > /sys/block/mmcblk0/queue/rq_affinity
echo '2' > /sys/block/mmcblk0/queue/nomerges
echo '1024' > /sys/block/mmcblk0/queue/nr_requests
# Memory Tuning
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/block/ram13/queue/read_ahead_kb
echo '1024' > /sys/block/ram14/queue/read_ahead_kb
echo '1024' > /sys/block/ram15/queue/read_ahead_kb
echo '1024' > /sys/block/vnswap0/queue/read_ahead_kb
# ZRAM
echo '1024' > /sys/block/zram0/queue/read_ahead_kb
# Touch
setprop touch.pressure.scale=0.0001;
setprop pm.dexopt.bg-dexopt=speed-profile;
setprop pm.dexopt.shared=speed;
fi;
# Disable Fsync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor schedutil
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 100
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor msm-adreno-tz
write /sys/class/kgsl/kgsl-3d0/devfreq/governor msm-adreno-tz
write /sys/module/adreno_idler/parameters/adreno_idler_active 1
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /dev/cpuset/foreground/cpus 7-7
write /dev/cpuset/foreground/boost/cpus 7-7
write /dev/cpuset/top-app/cpus 0-7
done
# Opti
setprop vendor.perf.gestureflingboost.enable false
# Wakelock Blocker
write /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker "qcom_rx_wakelock;wlan;wlan_wow_wl;wlan_extscan_wl;netmgr_wl;NETLINK;IPA_WS;[timerfd];wlan_ipa;wlan_pno_wl;wcnss_filter_lock;IPCRTR_lpass_rx;hal_bluetooth_lock"
# Disable Find My Device (in order to have optimized GMS for Android 9 or later);
su -c "pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver"
echo 0-7 > /dev/cpuset/system-background/cpus
echo 0 > /dev/stune/top-app/schedtune.colocate
echo 1 > /dev/stune/top-app/schedtune.sched_boost_enabled
echo 1 > /dev/stune/top-app/schedtune.sched_boost_no_override
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 100 > /dev/stune/top-app/schedtune.boost
echo 0 > /dev/stune/foreground/schedtune.colocate
echo 1 > /dev/stune/foreground/schedtune.sched_boost_enabled
echo 1 > /dev/stune/foreground/schedtune.sched_boost_no_override
echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 100 > /dev/stune/foreground/schedtune.boost
echo 0 > /dev/stune/background/schedtune.colocate
echo 1 > /dev/stune/background/schedtune.sched_boost_enabled
echo 1 > /dev/stune/background/schedtune.sched_boost_no_override
echo 1 > /dev/stune/background/schedtune.prefer_idle
echo 100 > /dev/stune/background/schedtune.boost
echo 0 > /dev/stune/schedtune.colocate
echo 1 > /dev/stune/schedtune.sched_boost_enabled
echo 1 > /dev/stune/schedtune.sched_boost_no_override
echo 0 > /dev/stune/schedtune.prefer_idle
echo 100 > /dev/stune/schedtune.boost
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 100
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/module/msm_performance/parameters/touchboost 1
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor performance
write /sys/class/kgsl/kgsl-3d0/devfreq/governor performance
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
# Boost
echo "0:0 4:0" > /sys/module/cpu_boost/parameters/topkek_boost_freq
echo '180' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '0:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '1:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '2:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '3:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '4:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '5:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '6:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '7:0' > /sys/module/cpu_boost/parameters/input_boost_freq
echo '180' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/performance/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/iowait_boost_enable
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_load
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/performance/pl
#I/O
echo 'deadline' > /sys/block/mmcblk0/queue/scheduler
echo 'deadline' > /sys/block/mmcblk1/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '1024' > /sys/block/mmcblk1/queue/read_ahead_kb
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
# TCP Type
sysctl -w net.ipv4.tcp_congestion_control=cubic
# Internet Tweaks
for tcp in /proc/sys/net/ipv4/
do
write "${tcp}ip_no_pmtu_disc" "0"
write "${tcp}tcp_ecn" "2"
write "${tcp}tcp_timestamps" "0"
write "${tcp}route.flush" "1"
write "${tcp}tcp_rfc1337" "1"
write "${tcp}tcp_tw_reuse" "1"
write "${tcp}tcp_sack" "1"
write "${tcp}tcp_fack" "1"
write "${tcp}tcp_fastopen" "3"
write "${tcp}tcp_tw_recycle" "1"
write "${tcp}tcp_no_metrics_save" "0"
write "${tcp}tcp_syncookies" "0"
write "${tcp}tcp_window_scaling" "1"
write "${tcp}tcp_keepalive_probes" "10"
write "${tcp}tcp_keepalive_intvl" "30"
write "${tcp}tcp_fin_timeout" "30"
write "${tcp}tcp_low_latency" "1"
write "${tcp}tcp_congestion_control" "cubic"
done
# TCP Mod
echo 0 > /proc/sys/net/ipv4/conf/default/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/default/accept_source_route
echo 0 > /proc/sys/net/ipv4/conf/all/secure_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_redirects
echo 0 > /proc/sys/net/ipv4/conf/all/accept_source_route
echo 0 > /proc/sys/net/ipv4/ip_forward
echo 0 > /proc/sys/net/ipv4/ip_dynaddr
echo 0 > /proc/sys/net/ipv4/ip_no_pmtu_disc
echo 0 > /proc/sys/net/ipv4/tcp_ecn
echo 0 > /proc/sys/net/ipv4/tcp_timestamps
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse
echo 1 > /proc/sys/net/ipv4/tcp_fack
echo 1 > /proc/sys/net/ipv4/tcp_sack
echo 1 > /proc/sys/net/ipv4/tcp_dsack
echo 1 > /proc/sys/net/ipv4/tcp_rfc1337
echo 1 > /proc/sys/net/ipv4/tcp_tw_recycle
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling
echo 1 > /proc/sys/net/ipv4/tcp_moderate_rcvbuf
echo 1 > /proc/sys/net/ipv4/tcp_no_metrics_save
echo 2 > /proc/sys/net/ipv4/tcp_synack_retries
echo 2 > /proc/sys/net/ipv4/tcp_syn_retries
echo 5 > /proc/sys/net/ipv4/tcp_keepalive_probes
echo 30 > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo 30 > /proc/sys/net/ipv4/tcp_fin_timeout
echo 1800 > /proc/sys/net/ipv4/tcp_keepalive_time
echo 5505024 > /proc/sys/net/core/rmem_max
echo 5505024 > /proc/sys/net/core/wmem_max
echo 5505024 > /proc/sys/net/core/rmem_default
echo 5505024 > /proc/sys/net/core/wmem_default
echo "20480" > /proc/sys/net/core/optmem_max;
echo "524288 1048576 5505024" > /proc/sys/net/ipv4/tcp_rmem;
echo "262144 524288 5505024" > /proc/sys/net/ipv4/tcp_wmem;
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts;
echo "1" > /proc/sys/net/ipv4/icmp_echo_ignore_all;
# Doze
settings delete global device_idle_constants
settings delete global device_idle_constants_user
dumpsys deviceidle enable light
dumpsys deviceidle enable deep
settings put global device_idle_constants light_after_inactive_to=30000,light_pre_idle_to=35000,light_idle_to=30000,light_idle_factor=1.7,light_max_idle_to=50000,light_idle_maintenance_min_budget=28000,light_idle_maintenance_max_budget=300000,min_light_maintenance_time=5000,min_deep_maintenance_time=10000,inactive_to=30000,sensing_to=0,locating_to=0,location_accuracy=2000,motion_inactive_to=86400000,idle_after_inactive_to=0,idle_pending_to=30000,max_idle_pending_to=60000,idle_pending_factor=2.1,quick_doze_delay_to=60000,idle_to=3600000,max_idle_to=21600000,idle_factor=1.7,min_time_to_alarm=1800000,max_temp_app_whitelist_duration=20000,mms_temp_app_whitelist_duration=20000,sms_temp_app_whitelist_duration=10000,notification_whitelist_duration=20000,wait_for_unlock=true,pre_idle_factor_long=1.67,pre_idle_factor_short=0.33
# Brightness
if [ `cat /sys/class/leds/lcd-backlight/brightness` == "0" ]; then
settings put global low_power "1"
settings put secure location_mode "0"
settings put secure location_providers_allowed ""
cmd netpolicy set restrict-background "true"
else
settings put global low_power "0"
settings put secure location_mode "0"
cmd netpolicy set restrict-background "false"
fi;
# Wakelock
echo 'qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;NETLINK;NETLINK;NETLINK;mpss_IPCRTR;NETLINK;eventpoll;NETLINK;IPCRTR_mpss_rx;NETLINK;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker
echo 'qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;NETLINK;NETLINK;NETLINK;mpss_IPCRTR;NETLINK;eventpoll;NETLINK;IPCRTR_mpss_rx;NETLINK;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/devices/virtual/misc/boeffla_wakelock_blocker/wakelock_blocker 
echo 'qcom_sap_wakelock;DIAG_WS;CHG_PLCY_MAIN_WL;WLAN_CE_2;a800000.ssusb;800f000.qcom;pm660@0:qpnp,fg;spmi:qcom;qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;mpss_IPCRTR;eventpoll;IPCRTR_mpss_rx;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/devices/virtual/misc/boeffla_wakelock_blocker/wakelock_blocker
echo 'qcom_sap_wakelock;DIAG_WS;CHG_PLCY_MAIN_WL;WLAN_CE_2;a800000.ssusb;800f000.qcom;pm660@0:qpnp,fg;spmi:qcom;qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;mpss_IPCRTR;eventpoll;IPCRTR_mpss_rx;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/devices/virtual/misc/boeffla_wakelock_blocker/wakelock_blocker
echo 'qcom_sap_wakelock;DIAG_WS;CHG_PLCY_MAIN_WL;WLAN_CE_2;a800000.ssusb;800f000.qcom;pm660@0:qpnp,fg;spmi:qcom;qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;mpss_IPCRTR;eventpoll;IPCRTR_mpss_rx;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker
echo 'qcom_sap_wakelock;DIAG_WS;CHG_PLCY_MAIN_WL;WLAN_CE_2;a800000.ssusb;800f000.qcom;pm660@0:qpnp,fg;spmi:qcom;qcom_rx_wakelock;wcnss_filter_lock;wlan;wlan_ipa;IPA_WS;wlan_pno_wl;wlan_wow_wl;wlan_extscan_wl;net;IPCRTR_lpass_rx;eventpoll;event2;KeyEvents;eventpoll;mpss_IPCRTR;eventpoll;IPCRTR_mpss_rx;eventpoll;[timerfd];hal_bluetooth_lock;sensor_ind;netmgr_wl;qcom_rx_wakelock;wlan_extscan_wl;NETLINK;bam_dmux_wakelock;IPA_RM12' > /sys/class/misc/boeffla_wakelock_blocker/wakelock_blocker
# Misc
setprop ro.FOREGROUND_APP_MEM=1280;
setprop ro.VISIBLE_APP_MEM=2560;
setptop ro.PERCEPTIBLE_APP_MEM=3840;
setprop ro.HEAVY_WEIGHT_APP_MEM=6400;
setprop ro.SECONDARY_SERVER_MEM=7680;
setptop ro.BACKUP_APP_MEM=8960;
setprop ro.HOME_APP_MEM=2048;
setprop ro.CONTENT_PROVIDER_MEM=15360;
setptop ro.HIDDEN_APP_MEM=12800;
setprop ro.EMPTY_APP_MEM=20480;
setprop ro.FOREGROUND_APP_ADJ=0;
setptop ro.VISIBLE_APP_ADJ=1;
setprop ro.HEAVY_WEIGHT_APP_ADJ=4;
setptop ro.PERCEPTIBLE_APP_ADJ=2;
setprop ro.SECONDARY_SERVER_ADJ=5;
setprop ro.HOME_APP_ADJ=1;
setptop ro.BACKUP_APP_ADJ=6;
setprop ro.HIDDEN_APP_MIN_ADJ=7;
setprop ro.EMPTY_APP_ADJ=15;
setprop debug.sf.hw=1;
setprop video.accelerate.hw=1;
setprop ro.HOME_APP_ADJ=1;
setprop ro.mot.eri.losalert.delay=1000;
setprop ro.config.hw_quickpoweron=true;
setprop ro.config.hw_fast_dormancy=1;
setprop ro.ril.enable.amr.wideband=1;
setprop persist.sys.NV_FPSLIMIT=90;
setprop ro.telephony.sms_segment_size=160;
setprop persist.telephony.support.ipv4=1;
setprop persist.telephony.support.ipv6=1;
setprop persist.sys.shutdown.mode=hibernate;
setprop ro.config.hw_fast_dormancy=1;
setprop ro.config.hw_power_saving=true;
setprop ro.media.enc.hprof.vid.fps=65;
setprop ro.mot.buttonlight.timeout=1;
setprop ro.media.dec.jpeg.memcap=99999999;
setprop ro.media.enc.hprof.vid.bps=999999999;
setprop ro.media.enc.jpeg.quality=100;
setprop mot.proximity.delay=25;
setprop ro.telephony.call_ring.delay=0;
setprop ro.lge.proximity.delay=25;
setprop wifi.supplicant_scan_interval=300;
setprop pm.sleep_mode=1;
setprop ro.ril.disable.power.collapse=1;
setprop windowsmgr.max_events_per_sec=90;
setprop persist.cust.tel.eons=1;
setprop profiler.force_disable_ulog=1;
setprop ro.config.nocheckin=1;
setprop profiler.force_disable_err_rpt=1;
setprop ro.media.dec.jpeg.memcap=99999999;
setprop ro.media.enc.hprof.vid.bps=999999999;
setprop persist.cust.tel.eons=1;
setprop profiler.force_disable_err_rpt=1;
setprop windowsmgr.max_events_per_sec=90;
setprop ro.ril.disable.power.collapse=1;
setprop media.stagefright.enable-record=true;
setprop debug.performance.tuning=1;
setprop media.stagefright.enable-http=true;
setprop media.stagefright.enable-scan=true;
setprop media.stagefright.enable-meta=true;
setprop touch.presure.scale=0.001;
setprop media.stagefright.enable-player=true;
setprop ro.ril.set.mtu1472=1;
setprop ro.config.nocheckin=1;
setprop ro.media.enc.jpeg.quality=100;
setprop profiler.force_disable_ulog=1;
setprop wifi.supplicant_scan_interval=300;
setprop pm.sleep_mode=1;
setprop ro.telephony.call_ring.delay=0;
setprop ro.lge.proximity.delay=25;
setprop mot.proximity.delay=25;
setprop dalvik.vm.verify-bytecode=false;
setprop dalvik.vm.execution-mode=int:fast;
setprop dalvik.vm.checkjni=false;
setprop dalvik.vm.dexopt-data-only=1;
setprop dalvik.vm.heapstartsize=1m;
setprop dalvik.vm.heapgrowthlimit=64m;
setprop dalvik.vm.verify-bytecode=false;
setprop dalvik.vm.heapsize=128m;
setprop dalvik.vm.execution-mode=int:jit;
setprop dalvik.vm.lockprof.threshold=250;
setprop dalvik.vm.dexopt-flags=m=v,o=y;
setprop dalvik.vm.jmiopts=forcecopy;
setprop debug.composition.type=gpu;
setprop debug.overlayui.enable=1;
setprop debug.performance.tuning=1;
setprop debug.egl.profiler=1;
setprop debug.egl.hw=1;
setprop debug.sf.hw=1;
setprop hw3d.force=1;
setprop hw2d.force=1;
setprop force_hw_ui=true;
setprop profiler.force_disable_err_rpt=1;
setprop profiler.force_disable_ulog=1;
setprop ro.min_pointer_dur=8;
setprop debug.kill_allocating_task=0;
setprop persist.sys.ui.hw=1;
setprop ro.debuggable=1;
setprop ro.kernel.android.checkjni=0;
setprop ro.config.disable.hw_accel=false;
setprop persist.sys.purgeable_assets=1;
setprop ro.secure=0;
setprop persist.sys.use_dithering=1;
setprop persist.sys.use_16bpp_alpha=1;
fi;
if [[ "$GOVERNOR" = "interactive" && -e $DIRECTORY/timer_rate ]]; then
if [ -e $DIRECTORY/timer_rate ]; then
  SAMPLING_RATE=`cat $DIRECTORY/timer_rate 2>/dev/null`
  if [ "$SAMPLING_RATE" -gt 100000 ]; then
    SET_VALUE "100000" $DIRECTORY/timer_rate 2>/dev/null
  fi
  if [ "$SAMPLING_RATE" -lt 40000 ]; then
    SET_VALUE "40000" $DIRECTORY/timer_rate 2>/dev/null
  fi
fi
  
if [[ -f /system/etc/CrossBreeder/START_TWEAKING_GOVERNOR || "$1" = "FORCE" ]]; then 

if [ "$GOVERNOR" = "interactive" ]; then
        SET_VALUE "100" $DIRECTORY/go_maxspeed_load 2>/dev/null
        SET_VALUE "100" $DIRECTORY/go_hispeed_load 2>/dev/null
        SET_VALUE "10000" $DIRECTORY/min_sample_time 2>/dev/null
        SET_VALUE "40000" $DIRECTORY/timer_rate 2>/dev/null
elif [ "$GOVERNOR" = "ondemand" ]; then
        SET_VALUE "100" $DIRECTORY/up_threshold 2>/dev/null
#        SET_VALUE "0" $DIRECTORY/powersave_bias 2>/dev/null
        SET_VALUE "10" $DIRECTORY/down_differential 2>/dev/null
        SET_VALUE "1" $DIRECTORY/sampling_down_factor 2>/dev/null
#        SET_VALUE "1" $DIRECTORY/io_is_busy 2>/dev/null
        SET_VALUE "0" $DIRECTORY/ignore_nice_load 2>/dev/null
#        SET_VALUE "192000" $DIRECTORY/sampling_rate 2>/dev/null
        SET_VALUE "192000" $DIRECTORY/sampling_rate 2>/dev/null
elif [ "$GOVERNOR" = "ondemandx" ]; then
        SET_VALUE "85" $DIRECTORY/up_threshold 2>/dev/null
#        SET_VALUE "50" $DIRECTORY/powersave_bias 2>/dev/null
        SET_VALUE "10" $DIRECTORY/down_differential 2>/dev/null
        SET_VALUE "1" $DIRECTORY/sampling_down_factor 2>/dev/null
        SET_VALUE "0" $DIRECTORY/ignore_nice_load 2>/dev/null
#        SET_VALUE "100000" $DIRECTORY/sampling_rate 2>/dev/null
        SET_VALUE "40000" $DIRECTORY/sampling_rate 2>/dev/null                                        
elif [ "$GOVERNOR" = "conservative" ]; then
        SET_VALUE "85" $DIRECTORY/up_threshold 2>/dev/null
	SET_VALUE "75" $DIRECTORY/down_threshold 2>/dev/null 
        SET_VALUE "100" $DIRECTORY/freq_step 2>/dev/null 
elif [ "$GOVERNOR" = "lulzactive" ]; then
	SET_VALUE "85" $DIRECTORY/inc_cpu_load 2>/dev/null
	SET_VALUE "1" $DIRECTORY/pump_down_step 2>/dev/null
elif [ "$GOVERNOR" = "smartass" ]; then
	SET_VALUE "500000" $DIRECTORY/awake_ideal_freq 2>/dev/null
	CAT /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq > $DIRECTORY/sleep_ideal_freq 2>/dev/null
	SET_VALUE "800000" $DIRECTORY/sleep_wakeup_freq 2>/dev/null
	SET_VALUE "85" $DIRECTORY/max_cpu_load 2>/dev/null
	SET_VALUE "75" $DIRECTORY/min_cpu_load 2>/dev/null
	SET_VALUE "200000" $DIRECTORY/ramp_down_step 2>/dev/null
	SET_VALUE "0" $DIRECTORY/ramp_up_step 2>/dev/null
elif [ "$GOVERNOR" = "abyssplug" ]; then
	SET_VALUE "85" $DIRECTORY/up_threshold 2>/dev/null
	SET_VALUE "40" $DIRECTORY/down_threshold 2>/dev/null
	SET_VALUE "5" $DIRECTORY/hotplug_in_sampling_periods 2>/dev/null
	SET_VALUE "20" $DIRECTORY/hotplug_out_sampling_periods 2>/dev/null
	SET_VALUE "10" $DIRECTORY/down_differential 2>/dev/null
	SET_VALUE "40000" $DIRECTORY/sampling_rate 2>/dev/null
elif [ "$GOVERNOR" = "pegasusq" ]; then
	SET_VALUE "85" $DIRECTORY/up_threshold 2>/dev/null
	SET_VALUE "10" $DIRECTORY/down_differential 2>/dev/null
	SET_VALUE "1" $DIRECTORY/sampling_down_factor 2>/dev/null
	SET_VALUE "40000" $DIRECTORY/sampling_rate 2>/dev/null
	SET_VALUE "100" $DIRECTORY/freq_step 2>/dev/null
	SET_VALUE "5" $DIRECTORY/cpu_up_rate 2>/dev/null
	SET_VALUE "20" $DIRECTORY/cpu_down_rate 2>/dev/null
	SET_VALUE "100000" $DIRECTORY/freq_for_responsiveness 2>/dev/null
elif [ "$GOVERNOR" = "hotplug" ]; then
	SET_VALUE "100" $DIRECTORY/up_threshold 2>/dev/null
	SET_VALUE "40" $DIRECTORY/down_threshold 2>/dev/null
	SET_VALUE "5" $DIRECTORY/hotplug_in_sampling_periods 2>/dev/null
	SET_VALUE "20" $DIRECTORY/hotplug_out_sampling_periods 2>/dev/null
	SET_VALUE "10" $DIRECTORY/down_differential 2>/dev/null
	SET_VALUE "40000" $DIRECTORY/sampling_rate 2>/dev/null
fi
fi
# Zram
echo 1 > /sys/block/zram0/reset
echo 4096M > /sys/block/zram0/disksize
# build.prop
#lmkd 
setprop ro.lmk.low=1001;
setprop ro.lmk.medium=800;
setprop ro.lmk.critical=0;
setprop ro.lmk.critical_upgrade=false;
setprop ro.lmk.upgrade_pressure=100;
setprop ro.lmk.downgrade_pressure=100;
setprop ro.lmk.killheaviesttask=true;
setprop ro.lmk.useminfreelevels=true;
setprop ro.lmk.use_psi=true;
#lmkd 
setprop ro.lmk.psipartialstall_ms=70;
setprop ro.lmk.psicompletestall_ms=700;
setprop ro.lmk.thrashing_limit=100;
setprop ro.lmk.thrashinglimitdecay=10;
setprop ro.lmk.swaputilmax=100;
setprop ro.lmk.swapfreelow_percentage=20;
setprop ro.lmk.debug=false;
fi;
# Sd card
if [ -e /sys/devices/virtual/bdi/0:18/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/0:18/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/179:0/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/179:0/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:0/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:0/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:1/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:1/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:2/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:2/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:3/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:3/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:4/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:4/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:5/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:5/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:6/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:6/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/7:7/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/7:7/read_ahead_kb
fi
if [ -e /sys/devices/virtual/bdi/default/read_ahead_kb ]; then
    echo $READ_AHEAD_KB > /sys/devices/virtual/bdi/default/read_ahead_kb
fi
# Boost
if [ -e /proc/sys/kernel/hung_task_timeout_secs ]
then
echo 45 > /proc/sys/kernel/hung_task_timeout_secs;s
#(busybox expr `cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_transition_latency` \* 750 / 1000);
echo $SAMPLING_RATE > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/sampling_rate;
echo 192000 > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/sampling_rate;
echo 100 > /sys/devices/system/cpu/cpu0/cpufreq/ondemand/up_threshold;
# Allow configuring of both cores
echo "1" > /sys/devices/system/cpu/cpu0/online;
echo "1" > /sys/devices/system/cpu/cpu1/online;
done
#for opt in DYN_MIN_VRUNTIME \
#        NO_FAIR_SLEEPERS FAIR_SLEEPERS_INTERACTIVE FAIR_SLEEPERS_TIMER \
#        INTERACTIVE TIMER \
#        INTERACTIVE_FORK_EXPEDITED TIMER_FORK_EXPEDITED;
do echo $opt > /sys/kernel/debug/sched_features;
done
# CFS options moved elsewhere!
if [ -e /proc/sys/kernel/rr_interval ];
then
# BFS;
echo 6 > /proc/sys/kernel/rr_interval;
echo 75 > /proc/sys/kernel/iso_cpu;
else
# CFS
# following 2 settings are to be handled with care - could lead to bootlooping phone or other issues if too low !
echo 18000000 > /proc/sys/kernel/sched_latency_ns;
echo 500000 > /proc/sys/kernel/sched_wakeup_granularity_ns	; 
echo 1500000 > /proc/sys/kernel/sched_min_granularity_ns; 
echo 200000 > /proc/sys/kernel/sched_min_granularity_ns; 
echo 18000000 > /proc/sys/kernel/sched_latency_ns;
echo 3000000 > /proc/sys/kernel/sched_wakeup_granularity_ns; 
echo -1 > /proc/sys/kernel/sched_rt_runtime_us; 
echo 100000 > /proc/sys/kernel/sched_rt_period_us;
echo 95000 > /proc/sys/kernel/sched_rt_runtime_us; # default: 950000; very small values in sched_rt_runtime_us can result in an unstable system when the runtime is so small 
# the system has difficulty making forward progress (the migration thread and kstopmachine both are real-time processes)
fi;
# Multi
setprop MIN_HIDDEN_APPS false
setprop ACTIVITY_INACTIVE_RESET_TIME false
setprop MIN_RECENT_TASKS false
setprop PROC_START_TIMEOUT false
setprop CPU_MIN_CHECK_DURATION false
setprop GC_TIMEOUT false
setprop SERVICE_TIMEOUT false
setprop MIN_CRASH_INTERVAL false
setprop ENFORCE_PROCESS_LIMIT false
setprop CONTENT_APP_IDLE_OFFSET false
setprop EMPTY_APP_IDLE_OFFSET false
setprop MAX_ACTIVITIES false
setprop MAX_HIDDEN_APPS false
setprop MAX_PROCESSES false
setprop MAX_RECENT_TASKS false
setprop MAX_SERVICE_INACTIVITY false
setprop APP_SWITCH_DELAY_TIME false
# Hal
system system /dev/stune/top-app/schedtune.boost
chown system system /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
chown system system /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
chown system system /sys/class/kgsl/kgsl-3d0/force_rail_on
chown system system /sys/class/kgsl/kgsl-3d0/force_clk_on
chown system system /sys/class/kgsl/kgsl-3d0/idle_timer
chown system system /sys/class/devfreq/soc:qcom,gpubw/min_freq
chown system system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/min_freq
chown system system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/bw_hwmon/hyst_trigger_count
chown system system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/bw_hwmon/hist_memory
chown system system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/bw_hwmon/hyst_length
chown system system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/min_freq
# Init Power HAL
# Without this hal will waiting for it
setprop vendor.powerhal.init 1














